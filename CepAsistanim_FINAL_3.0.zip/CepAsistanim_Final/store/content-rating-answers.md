# İçerik derecelendirmesi için taslak cevaplar

Uygulama: Cep Asistanım

Şiddet: Yok
Cinsel içerik: Yok
Kumar: Yok
Uyuşturucu: Yok
Hakaret/küfür: Yok
Korku: Yok
Kullanıcılar arası iletişim: Yok
Konum paylaşımı: Yok
Çocuklara yönelik hedefleme: Hayır

Not: Google Play Console'daki resmi soru formu, yayınlanan son uygulama davranışına göre geliştirici tarafından doğrulanmalıdır.
