# 3.0
- Play Billing 9.1.0 integrated
- Mobile Ads SDK 25.5.0 integrated with Google test App ID
- Pro subscription flow scaffold
- Privacy, Terms, Store Listing, Data Safety and Content Rating drafts
- Android 16 / API 36 target
- Local AI fallback
