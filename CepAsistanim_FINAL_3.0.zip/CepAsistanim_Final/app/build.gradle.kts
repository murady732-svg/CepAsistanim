plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace="com.cepasistanim.app"
    compileSdk=36
    defaultConfig {
        applicationId="com.cepasistanim.app"
        minSdk=24
        targetSdk=36
        versionCode=3
        versionName="3.0"
    }
}
dependencies {
    implementation("com.android.billingclient:billing-ktx:9.1.0")
    implementation("com.google.android.gms:play-services-ads:25.5.0")
}
