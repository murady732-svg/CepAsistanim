# Data Safety — Taslak

Bu dosya Play Console formunu doldurmak için çalışma taslağıdır.

Temel sürüm:
- Notlar: cihazda yerel saklama.
- Hesap açma: yok.
- Konum: yok.
- Kişiler: yok.
- Fotoğraf/video erişimi: temel sürümde yok.

SDK'lar:
- Google Mobile Ads: reklamlar etkinleştirildiğinde Google'ın veri işleme açıklamaları ayrıca değerlendirilmelidir.
- Google Play Billing: satın alma/abonelik işlemleri Google Play üzerinden gerçekleşir.

Bulut AI etkinleştirilirse veri türleri, paylaşım amacı, saklama süresi ve silme seçenekleri kullanılan sağlayıcıya göre güncellenmelidir.
