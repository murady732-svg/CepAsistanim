# Cep Asistanım — Kullanım Şartları

Son güncelleme: 27 Eylül 2026

Cep Asistanım günlük üretkenlik araçları sağlar. Uygulamadaki hesaplama, metin ve AI çıktıları hata içerebilir; önemli kararlar için bağımsız doğrulama yapılmalıdır.

Pro özellikleri abonelik veya Google Play üzerinden sunulan dijital ürünler olabilir. Satın alma ve abonelik koşulları Google Play'in ilgili ekranlarında gösterilir.

Uygulama kötüye kullanım, yasa dışı faaliyet veya başkalarının haklarını ihlal edecek şekilde kullanılmamalıdır.

İletişim: Geliştirici iletişim adresi yayın öncesinde eklenmelidir.
