# Cep Asistanım — Gizlilik Politikası

Son güncelleme: 27 Eylül 2026

Cep Asistanım, kullanıcıların günlük araçları kullanmasına yardımcı olan bir Android uygulamasıdır.

## Toplanan bilgiler
Bu temel sürümde kullanıcı tarafından uygulama içine yazılan notlar cihaz üzerinde yerel olarak saklanır. Uygulama, geliştiricinin kendi sunucusunda bu notların bir kopyasını oluşturmaz.

Reklam özelliği etkinleştirildiğinde Google Mobile Ads SDK'sı kendi hizmet şartları ve gizlilik belgelerine göre veri işleyebilir.

Google Play satın alma özelliği etkinleştirildiğinde satın alma işlemleri Google Play tarafından işlenir. Uygulama, abonelik hakkını doğrulamak için gerekli satın alma durumunu kullanabilir.

## AI
Bulut tabanlı AI özelliği etkinleştirildiğinde, kullanıcı tarafından gönderilen istemler AI hizmetine iletilebilir. Üretim sürümünde hangi sağlayıcının kullanıldığı ve veri saklama süresi bu bölümde açıkça belirtilmelidir.

## Çocuklar
Uygulama çocuklara özel olarak tasarlanmamıştır.

## İletişim
Geliştirici iletişim adresi yayın öncesinde buraya eklenmelidir.
