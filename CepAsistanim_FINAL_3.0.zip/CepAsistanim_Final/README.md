# Cep Asistanım 3.0 — Final Teknik Paket

Hedef: Android 16 / API 36
minSdk: 24
versionName: 3.0
applicationId: com.cepasistanim.app

## Dahil
- AI Asistan ekranı + cihaz içi fallback
- Hesap makinesi
- İndirim hesaplama
- Metin analizi
- Notlar
- PDF ürün alanı
- Google Play Billing Library 9.1.0
- Google Mobile Ads SDK 25.5.0
- Pro abonelik ürün kimliği: cep_asistanim_pro_monthly
- Gizlilik politikası taslağı
- Kullanım şartları taslağı
- Play Store açıklaması
- Content rating taslağı
- Data Safety taslağı

## Üretim kimlikleri
AdMob tarafında geliştirme için Google test App ID kullanılmıştır. Yayın öncesinde kendi AdMob App ID'nizle değiştirilmelidir.
Pro aboneliğin çalışması için Play Console'da cep_asistanim_pro_monthly ürünü oluşturulmalıdır.

## Gerçek AI
Güvenlik nedeniyle API anahtarı APK içine gömülmemiştir. Gerçek bulut AI için uygulama -> güvenli backend -> AI sağlayıcısı mimarisi kullanılmalıdır.

## Yayın
Google Play hesabı, ödeme profili, uygulama kaydı, AAB yükleme ve kapalı test işlemleri geliştirici hesabı üzerinden yapılır. Yeni kişisel hesaplarda Google'ın 12 test kullanıcısı / 14 gün şartı uygulanabilir.

Bu paket teknik kaynak paketidir; imzalı AAB ve hesap kimlikleri bu çalışma ortamında kullanıcı hesabı adına üretilemez.
