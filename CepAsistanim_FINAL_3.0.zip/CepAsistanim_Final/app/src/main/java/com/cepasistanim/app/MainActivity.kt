package com.cepasistanim.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*
import com.android.billingclient.api.*

class MainActivity: Activity(), PurchasesUpdatedListener {
 private lateinit var root:LinearLayout
 private lateinit var billing:BillingClient
 private val bg=Color.rgb(248,247,252)
 private val purple=Color.rgb(108,77,255)
 private var proAvailable=false
 private val proProductId="cep_asistanim_pro_monthly"

 override fun onCreate(b:Bundle?){super.onCreate(b); initBilling(); initAds(); home()}

 private fun initBilling(){
  billing=BillingClient.newBuilder(this).setListener(this).enablePendingPurchases(
   PendingPurchasesParams.newBuilder().enableOneTimeProducts().build()
  ).enableAutoServiceReconnection().build()
  billing.startConnection(object:BillingClientStateListener{
   override fun onBillingSetupFinished(r:BillingResult){ if(r.responseCode==BillingClient.BillingResponseCode.OK) queryPro() }
   override fun onBillingServiceDisconnected(){}
  })
 }
 private fun queryPro(){
  val p=QueryProductDetailsParams.Product.newBuilder().setProductId(proProductId).setProductType(BillingClient.ProductType.SUBS).build()
  billing.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(listOf(p)).build()){_,res->
   proAvailable=res.productDetailsList.isNotEmpty()
  }
 }
 private fun initAds(){ try{ com.google.android.gms.ads.MobileAds.initialize(this){} }catch(_:Exception){} }

 override fun onPurchasesUpdated(r:BillingResult?, list:MutableList<Purchase>?){
  if(r?.responseCode==BillingClient.BillingResponseCode.OK && list!=null) for(p in list) if(p.products.contains(proProductId)&&p.purchaseState==Purchase.PurchaseState.PURCHASED){proAvailable=true;Toast.makeText(this,"Pro aktif.",Toast.LENGTH_SHORT).show()}
 }

 private fun base(title:String):LinearLayout{
  root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(bg);setPadding(22,18,22,18)}
  val bar=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
  val t=TextView(this).apply{text=title;textSize=27f;setTextColor(Color.rgb(25,22,35));setTypeface(null,Typeface.BOLD)}
  bar.addView(t,LinearLayout.LayoutParams(0,70,1f));root.addView(bar);return root
 }
 private fun btn(s:String,f:()->Unit)=Button(this).apply{text=s;setOnClickListener{f()}}
 private fun card(s:String)=TextView(this).apply{text=s;textSize=17f;setTextColor(Color.DKGRAY);setPadding(20,20,20,20);setBackgroundColor(Color.WHITE)}
 private fun home(){
  val r=base("Cep Asistanım")
  r.addView(TextView(this).apply{text="Günlük işlerini tek uygulamada hallet.";textSize=16f;setPadding(0,0,0,14)})
  r.addView(card("✨ AI Asistan\nMetin oluştur • özetle • fikir üret"))
  r.addView(btn("🤖 AI Asistan"){ai()})
  r.addView(btn("🧰 Araçlar"){tools()})
  r.addView(btn("📌 Notlarım"){notes()})
  r.addView(btn("⭐ Pro"){pro()})
  r.addView(btn("⚙ Ayarlar"){settings()})
  r.addView(TextView(this).apply{text="\nSürüm 3.0";textSize=13f})
  setContentView(r)
 }
 private fun ai(){
  val r=base("AI Asistan")
  val q=EditText(this).apply{hint="Örn. Instagram tanıtım metni yaz";minLines=5;gravity=Gravity.TOP}
  val o=TextView(this).apply{textSize=16f;setPadding(0,16,0,16)}
  r.addView(q)
  r.addView(btn("✨ Oluştur"){
   val s=q.text.toString().trim()
   o.text=if(s.isEmpty())"Bir istek yaz." else localAssistant(s)
  })
  r.addView(o);r.addView(btn("← Ana Sayfa"){home()});setContentView(r)
 }
 private fun localAssistant(s:String):String{
  val l=s.lowercase()
  return when{
   l.contains("instagram")->"Başlık önerisi:\n\n✨ Yeni bir başlangıç, yeni bir hikâye.\n\nKısa açıklama:\nBugün kendin için bir adım at. Küçük adımlar, büyük değişimler oluşturur."
   l.contains("cv")->"CV için öneri:\n• Kısa profil özeti\n• Deneyimler\n• Eğitim\n• Yetenekler\n• İletişim bilgileri\n\nİstersen bu bölümleri doldurup profesyonel bir metne dönüştürebilirsin."
   l.contains("özet")->"Özetleme için metnini yaz. Bu sürüm temel cihaz içi araçlarla çalışır."
   else->"İsteğini aldım:\n\n$s\n\nBu sürümde cihaz içi yardımcı çalışıyor. Gerçek bulut AI sağlayıcısı için güvenli API sunucusu bağlandığında canlı AI yanıtları da kullanılabilir."
  }
 }
 private fun tools(){
  val r=base("Araçlar");r.addView(btn("🧮 Hesap Makinesi"){calculator()});r.addView(btn("💰 İndirim Hesapla"){discount()});r.addView(btn("📝 Metin Analizi"){textTool()});r.addView(btn("📄 PDF Araçları"){pdf()});r.addView(btn("← Ana Sayfa"){home()});setContentView(r)
 }
 private fun calculator(){
  val r=base("Hesap Makinesi");val e=EditText(this).apply{hint="Örn: 1200 + 350"};val o=TextView(this).apply{textSize=20f}
  r.addView(e);r.addView(btn("Hesapla"){try{val s=e.text.toString().replace(" ","");val op=listOf("+","-","*","/").first{s.contains(it)};val p=s.split(op);val a=p[0].toDouble();val b=p[1].toDouble();o.text="Sonuç: "+when(op){"+"->a+b;"-"->a-b;"*"->a*b;else->a/b}}catch(_:Exception){o.text="Örnek: 100 + 25"}});r.addView(o);r.addView(btn("← Araçlar"){tools()});setContentView(r)
 }
 private fun discount(){
  val r=base("İndirim Hesapla");val p=EditText(this).apply{hint="Fiyat ₺"};val d=EditText(this).apply{hint="İndirim %"};val o=TextView(this).apply{textSize=19f}
  r.addView(p);r.addView(d);r.addView(btn("Hesapla"){val x=p.text.toString().toDoubleOrNull();val y=d.text.toString().toDoubleOrNull();o.text=if(x!=null&&y!=null)"Yeni fiyat: %.2f ₺\nKazanç: %.2f ₺".format(x*(1-y/100),x*y/100) else "Bilgileri doldur."});r.addView(o);r.addView(btn("← Araçlar"){tools()});setContentView(r)
 }
 private fun textTool(){
  val r=base("Metin Analizi");val e=EditText(this).apply{hint="Metni yaz";minLines=7;gravity=Gravity.TOP};val o=TextView(this).apply{textSize=16f}
  r.addView(e);r.addView(btn("Analiz Et"){val s=e.text.toString();o.text="Karakter: ${s.length}\nKelime: ${s.trim().split(Regex("\\s+")).filter{it.isNotEmpty()}.size}\nCümle: ${s.count{it=='.'||it=='!'||it=='?'}}"});r.addView(o);r.addView(btn("← Araçlar"){tools()});setContentView(r)
 }
 private fun pdf(){
  val r=base("PDF Araçları");r.addView(card("PDF araçları için ürün alanı hazır. Pro ile planlanan özellikler:\n\n• Görselleri PDF yap\n• PDF birleştir\n• PDF metin çıkar\n• PDF sıkıştır"))
  r.addView(btn("⭐ Pro"){pro()});r.addView(btn("← Araçlar"){tools()});setContentView(r)
 }
 private fun notes(){
  val r=base("Notlarım");val e=EditText(this).apply{hint="Notunu yaz...";minLines=10;gravity=Gravity.TOP};val sp=getPreferences(0);e.setText(sp.getString("note",""))
  r.addView(e);r.addView(btn("Kaydet"){sp.edit().putString("note",e.text.toString()).apply();Toast.makeText(this,"Kaydedildi",Toast.LENGTH_SHORT).show()});r.addView(btn("← Ana Sayfa"){home()});setContentView(r)
 }
 private fun pro(){
  val r=base("Cep Asistanım Pro");r.addView(card("⭐ PRO\n\n• Reklamsız kullanım\n• Gelişmiş AI\n• PDF araçları\n• Yüksek kullanım limitleri"))
  r.addView(btn(if(proAvailable)"Pro ürünü bulundu — satın al" else "Pro ürünü Play Console'da etkinleşecek"){startProPurchase()})
  r.addView(btn("← Ana Sayfa"){home()});setContentView(r)
 }
 private fun startProPurchase(){
  val p=QueryProductDetailsParams.Product.newBuilder().setProductId(proProductId).setProductType(BillingClient.ProductType.SUBS).build()
  billing.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(listOf(p)).build()){r,res->
   val pd=res.productDetailsList.firstOrNull()
   if(r.responseCode!=BillingClient.BillingResponseCode.OK||pd==null){Toast.makeText(this,"Pro ürünü henüz Play Console'da tanımlı değil.",Toast.LENGTH_LONG).show();return@queryProductDetailsAsync}
   val offer=pd.subscriptionOfferDetails?.firstOrNull()
   if(offer==null){Toast.makeText(this,"Abonelik teklifi bulunamadı.",Toast.LENGTH_LONG).show();return@queryProductDetailsAsync}
   val params=BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(pd).setOfferToken(offer.offerToken).build()
   billing.launchBillingFlow(this,BillingFlowParams.newBuilder().setProductDetailsParamsList(listOf(params)).build())
  }
 }
 private fun settings(){
  val r=base("Ayarlar");r.addView(card("Cep Asistanım 3.0\n\nGizlilik: cihaz içi notlar yerel saklanır.\nAI: gerçek bulut AI bağlantısı güvenli sunucu üzerinden yapılmalıdır.\nReklam: geliştirme sırasında Google test reklam kimliği kullanılır."))
  r.addView(btn("← Ana Sayfa"){home()});setContentView(r)
 }
}
