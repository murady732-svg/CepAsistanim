# Cep Asistanım

## Kısa açıklama
Günlük hesaplama, metin, not ve akıllı yardımcı araçları tek yerde.

## Tam açıklama
Cep Asistanım, telefonunda günlük işlerini daha kolay yönetmen için tasarlanmış pratik bir yardımcı uygulamadır.

Öne çıkan araçlar:
• AI Asistan
• Hesap makinesi
• İndirim hesaplama
• Metin analizi
• Notlar
• PDF araçları
• Pro özellikleri

Basit işlemler için hızlı araçlar kullanabilir, notlarını cihazında saklayabilir ve uygulama geliştikçe yeni üretkenlik özelliklerinden yararlanabilirsin.

Pro sürüm; reklamsız kullanım, gelişmiş AI özellikleri ve ek araçlar gibi ücretli özellikler içerebilir.
